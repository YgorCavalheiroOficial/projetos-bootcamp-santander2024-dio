package one.digiitalinovation.gof;

import one.digiitalinovation.gof.facede.Facede;
import one.digiitalinovation.gof.singleton.SingletonEager;
import one.digiitalinovation.gof.singleton.SingletonLazy;
import one.digiitalinovation.gof.singleton.SingletonLazyHolder;
import one.digiitalinovation.gof.strategy.*;

public class Test {
    public static void main(String[] args){

        //Singleton;

        SingletonLazy lazy = SingletonLazy.getInstancia();
        System.out.println(lazy);
        lazy = SingletonLazy.getInstancia();
        System.out.println(lazy);

        SingletonEager eager = SingletonEager.getInstancia();
        System.out.println(eager);
        eager = SingletonEager.getInstancia();
        System.out.println(eager);

        SingletonLazyHolder lazyHolder = SingletonLazyHolder.getInstancia();
        System.out.println(lazyHolder);
        lazyHolder = SingletonLazyHolder.getInstancia();
        System.out.println(lazyHolder);

        //Strategy

        Comportamento defensivo = new ComportamentoDefensivo();
        Comportamento normal = new ComportamentoNormal();
        Comportamento agressivo = new ComportamentoAgressivo();

        Robo robo = new Robo();
        robo.setStrategy(normal);
        robo.mover();
        robo.mover();
        robo.setStrategy(defensivo);
        robo.mover();
        robo.setStrategy(agressivo);
        robo.mover();

        //Facede

        Facede facede  = new Facede();
        facede.migrarCliente("Ygor", "123456");
    }
}
