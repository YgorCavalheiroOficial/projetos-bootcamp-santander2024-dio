package one.digiitalinovation.gof.strategy;

public interface Comportamento {
    void mover();
}
